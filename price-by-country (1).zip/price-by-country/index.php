<?php
// Silence is golden.
